using fiveyears3.Scripts.Utilidades;
using Flags;
using Godot;
using System;

namespace fiveyears3.Scripts.Globais;

public partial class GerenciadorDeEventoAleatorio : Node
{
    public enum TipoEventoAleatorio { Nenhum, AntenaQuebrada, RevoltaPopularIniciandoGovernoBateAPorta }
    public TipoEventoAleatorio TipoEventoAleatorioAtual { get; private set; } = TipoEventoAleatorio.Nenhum;

    private IEventoAleatorio _eventoAtivo;
    public static GerenciadorDeEventoAleatorio Instance { get; private set; }

    public override void _Ready()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        if (GerenciadorDeFlagsNarrativas.Instance != null)
        {
            GerenciadorDeFlagsNarrativas.Instance.OnFlagAtivada += ProcessarDisparoDeEvento;
        }
    }

    public override void _ExitTree()
    {
        if (GerenciadorDeFlagsNarrativas.Instance != null)
        {
            GerenciadorDeFlagsNarrativas.Instance.OnFlagAtivada -= ProcessarDisparoDeEvento;
        }
    }

    private void ProcessarDisparoDeEvento(FlagNarrativa flag)
    {
        Log.Print($"[GerenciadorDeEventoAleatorio] Flag narrativa ativada: {flag}");
        switch (flag)
        {
            case FlagNarrativa.AntenaQuebrada_01:
                DispararEvento(TipoEventoAleatorio.AntenaQuebrada, new AntenaQuebrada());
                break;
            case FlagNarrativa.RevoltaPopularIniciandoGovernoBateAPorta:
                DispararEvento(TipoEventoAleatorio.RevoltaPopularIniciandoGovernoBateAPorta, new RevoltaPopularIniciandoGovernoBateAPorta());
                break;
        }
    }

    private void DispararEvento(TipoEventoAleatorio tipo, IEventoAleatorio instanciaEvento)
    {
        Log.Print($"[GerenciadorDeEventoAleatorio] Disparando evento: {tipo}");
        _eventoAtivo?.FinalizarEvento();
        TipoEventoAleatorioAtual = tipo;
        _eventoAtivo = instanciaEvento;
        _eventoAtivo.IniciarEvento();
    }

    public void ConcluirEventoAtual()
    {
        if (_eventoAtivo != null)
        {
            _eventoAtivo.FinalizarEvento();
            _eventoAtivo = null;
            TipoEventoAleatorioAtual = TipoEventoAleatorio.Nenhum;
        }
    }
}

public interface IEventoAleatorio
{
    void IniciarEvento();
    void FinalizarEvento();
}

#region Eventos Aleatorios


public class RevoltaPopularIniciandoGovernoBateAPorta : IEventoAleatorio
{
    private const string CAMINHO_PORTA =
        "ConfiguracaoGlobal/Estruturas/Porta";

    private Porta _porta;

    public void IniciarEvento()
    {
        _porta = LocalizaObjetoEmCena<Porta>.LocalizarObjeto(CAMINHO_PORTA);

        if (_porta == null)
            return;

        _porta.PrepararCarta(new DadosCarta
        {
            Titulo = "COMUNICADO FDP",
            Texto = "A situação nas ruas está se deteriorando. Você precisa cumprir seu papel! Controle essas pessoas."
        });

        _porta.AudioBatendoPorta.Play();
    }

    public void FinalizarEvento()
    {
    }
}
public class AntenaQuebrada : IEventoAleatorio
{
    private const string CAMINHO_ANTENA = "ConfiguracaoGlobal/Antena";
    private Antena _antena;

    public void IniciarEvento()
    {
        Log.Print($"[STRATEGY - AntenaQuebrada] Buscando nó no caminho: {CAMINHO_ANTENA}");

        Antena antena = LocalizaObjetoEmCena<Antena>.LocalizarObjeto(CAMINHO_ANTENA);
        antena?.QuebrarAntena();
    }

    public void FinalizarEvento()
    {
        Log.Print("[STRATEGY - AntenaQuebrada] Finalizando evento e consertando a antena.");

        if (GodotObject.IsInstanceValid(_antena))
        {
            _antena.ConsertarAntena();
            _antena = null;
        }
    }
}

#endregion


#region Auxilio
static class LocalizaObjetoEmCena<T> where T : GodotObject
{
    public static T LocalizarObjeto(string caminho)
    {
        var arvore = (SceneTree)Engine.GetMainLoop();
        var cenaAtual = arvore.CurrentScene;
        if (cenaAtual != null)
        {
            var objeto = cenaAtual.GetNodeOrNull<T>(caminho);
            if (GodotObject.IsInstanceValid(objeto))
            {
                Log.Print($"[LocalizaObjetoEmCena] Objeto localizado com sucesso no caminho: {caminho}");
                return objeto;
            }
            else
            {
                Log.PrintErr($"[LocalizaObjetoEmCena] Nó não encontrado no caminho fixo: {caminho}");
            }
        }
        else
        {
            Log.PrintErr("[LocalizaObjetoEmCena] Cena atual é nula. Não foi possível localizar o objeto.");
        }
        return null;
    }
}

#endregion